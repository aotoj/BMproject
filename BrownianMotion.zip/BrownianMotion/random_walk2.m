close all;clear;clc;clearvars;
N = 300; % Length of the x-axis, also known as the length of the random walks.
%M = 1;
M = 200; % The amount of random walks.
x_t(1) = 0;
y_t(1) = 0;
plot(x_t(1), y_t(1), '*')
hold on
for m=1:M
  for n = 1:N % Looping all values of N into x_t(n).
    A = sign(randn); % Generates either +1/-1 depending on the SIGN of RAND.
    x_t(n+1) = x_t(n) + A;
    A = sign(randn); % Generates either +1/-1 depending on the SIGN of RAND.
    y_t(n+1) = y_t(n) + A;
  end
  plot(x_t, y_t);
  hold on
end
grid on;
% Enlarge figure to full screen.
set(gcf, 'Units', 'Normalized', 'Outerposition', [0, 0.05, 1, 0.95]);
%axis square;
