close all; clear; clc; clearvars;
%n = 50;
n = 500;
%n = 4000;
x = 0;

for i = 1:n
    W(i) = x;
end

plot(0,W(1),'r*')
hold on
ones = [-1, 1];

for i = 2:n
    m = randi([1,2],1);
    Z = ones(m);%chooses positive or negative one
    W(i) = Z/sqrt(n) + W(i-1);% takes a random step depending on Z
    plot(i/n,W(i),'b.')
end